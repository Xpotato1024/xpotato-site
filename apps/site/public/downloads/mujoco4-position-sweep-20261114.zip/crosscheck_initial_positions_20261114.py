from pathlib import Path
import argparse
import json,copy
from xpotato_sim.runtime.composition.launch_profile import decode_launch_profile
from xpotato_sim.runtime.scene.objects import canonical
R = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--sim-checkout', type=Path, required=True,
                    help='Path to the Xpotato-Sim checkout at the manifest commit')
S = parser.parse_args().sim_checkout.resolve()
if not S.is_dir():
 raise SystemExit('--sim-checkout must be an existing directory')
base=json.loads((R/'profiles/coarse_off.json').read_text(encoding='utf-8'));base['workspace']=str(S);r=json.loads((R/'evidence/initial-position-sweep-20261114.json').read_text());out=[]
for row in r['rows']:
 if row['offset_mm'] not in [0,1]:continue
 d=copy.deepcopy(base);d['name']='phase-profile-crosscheck';d['execution']['physics'].update(physics_dt_s=row['dt_ms']/1000,speculative=row['speculative']);d['environment']['parameters']['scene']['objects'][0]['pose']['position_m'][0]+=row['offset_mm']/1000
 p=decode_launch_profile(canonical(d),source_path=R/'profiles/phase-crosscheck.json');q=p.build_model().provider;xs=[float(q.data.qpos[0])];v=[float(q.data.qvel[0])];cs=[int(q.data.ncon)]
 for i in range(round(.1/(row['dt_ms']/1000))):q.step(row['dt_ms']/1000);xs.append(float(q.data.qpos[0]));v.append(float(q.data.qvel[0]));cs.append(int(q.data.ncon))
 assert xs==row['x_m'] and v==row['vx_m_s'] and cs==row['ncon'];out.append({'dt_ms':row['dt_ms'],'speculative':row['speculative'],'offset_mm':row['offset_mm'],'max_x_m':row['max_x_m'],'complete_passage':row['complete_passage'],'profile_compilation_matches_state_offset':True,'x_m':xs,'ncon':cs})
print(json.dumps(out,indent=2));print('NO_WARNINGS',not any(any(x['warnings']) for x in r['rows']))
(R/'evidence/initial-position-crosscheck-20261114.json').write_text(json.dumps(out,indent=2)+'\n')
