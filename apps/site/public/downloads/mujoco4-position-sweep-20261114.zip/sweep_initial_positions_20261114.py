from pathlib import Path
import json,copy,subprocess,hashlib
import mujoco
from xpotato_sim.runtime.composition.launch_profile import decode_launch_profile
from xpotato_sim.runtime.scene.objects import canonical
R=Path(r'C:\Users\miyut\src\mujoco4-rtf-comparison-20261112');S=Path(r'C:\Users\miyut\src\sim-generic-mj4-20261111')
base=json.loads((R/'profiles/coarse_off.json').read_text(encoding='utf-8'))
rows=[];summary=[]
for dt,spec in [(.02,False),(.02,True),(.01,False),(.005,False),(.002,False)]:
 d=copy.deepcopy(base);d['name']='phase-sweep';d['execution']['physics'].update(physics_dt_s=dt,speculative=spec)
 p=decode_launch_profile(canonical(d),source_path=R/'profiles/phase-sweep.json');q=p.build_model().provider
 group=[]
 for mm in range(120):
  reps=[]
  for rep in range(3):
   q.reset();q.data.qpos[0]+=mm/1000;mujoco.mj_forward(q.model,q.data)
   xs=[float(q.data.qpos[0])];cs=[int(q.data.ncon)];vs=[float(q.data.qvel[0])]
   for i in range(round(.1/dt)):
    q.step(dt);xs.append(float(q.data.qpos[0]));cs.append(int(q.data.ncon));vs.append(float(q.data.qvel[0]))
   reps.append({'x_m':xs,'vx_m_s':vs,'ncon':cs,'warnings':q.data.warning.number.tolist()})
  assert reps[0]==reps[1]==reps[2]
  row={'dt_ms':dt*1000,'speculative':spec,'offset_mm':mm,'initial_x_m':-.18+mm/1000,'complete_passage':max(xs)>.015+1e-9,'centre_crossing':max(xs)>0,'max_x_m':max(xs),'repeat_count':3,'repeats_identical':True,**reps[0]};rows.append(row);group.append(row)
 sr={'dt_ms':dt*1000,'speculative':spec,'tested':len(group),'passage_count':sum(x['complete_passage'] for x in group),'passing_offsets_mm':[x['offset_mm'] for x in group if x['complete_passage']],'not_passing_offsets_mm':[x['offset_mm'] for x in group if not x['complete_passage']]};summary.append(sr);print(json.dumps(sr),flush=True)
res={'sim_commit':subprocess.check_output(['git','-C',str(S),'rev-parse','HEAD'],text=True).strip(),'mujoco_version':mujoco.__version__,'source_profile_sha256':hashlib.sha256((R/'profiles/coarse_off.json').read_bytes()).hexdigest(),'common_solref':base['environment']['parameters']['scene']['contact']['solref'],'duration_s':.1,'offsets':'0..119 mm inclusive, 1 mm increments, baseline x=-0.18m','definition_complete_passage':'sphere centre x > wall back face 0.005 m + radius 0.010 m + tolerance 1e-9 m at any sampled post-step state','summary':summary,'rows':rows}
(R/'evidence/initial-position-sweep-20261114.json').write_text(json.dumps(res,indent=2)+'\n',encoding='utf-8')
